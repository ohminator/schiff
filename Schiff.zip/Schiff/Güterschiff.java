
/**
 * Beschreiben Sie hier die Klasse Güterschiff.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Güterschiff extends Schiff
{
    // Instanzvariablen - ersetzen Sie das folgende Beispiel mit Ihren Variablen
    int MaxBeladung;
    boolean Tiertransport;

    /**
     * Konstruktor für Objekte der Klasse Güterschiff
     */
    public Güterschiff(String pHersteller, String pAntrieb, int pGeschwindigkeit, int pGewicht, int pBesatzungsgröße, int pMaxBeladung, boolean pTiertransport)
    {
        super(pHersteller, pAntrieb, pGeschwindigkeit, pGewicht, pBesatzungsgröße);
        MaxBeladung = pMaxBeladung;
        Tiertransport = pTiertransport;
    }

    public int getMaxBeladung() 
    {
        return MaxBeladung;
    }
    
    public void setMaxBeladung(int MaxBeladung) 
    {
         this.MaxBeladung = MaxBeladung;
    }
    
    public boolean getTiertransport() 
    {
        return Tiertransport;
    }
    
    public void setMaxBeladung(boolean Tiertransport) 
    {
         this.Tiertransport = Tiertransport;
    }
}
