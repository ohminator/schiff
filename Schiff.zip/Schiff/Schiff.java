
/**
 * Beschreiben Sie hier die Klasse Schiff.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Schiff
{
    // Instanzvariablen - ersetzen Sie das folgende Beispiel mit Ihren Variablen
    private String hersteller;
    private String antrieb;
    private int geschwindigkeit;
    private int gewicht;
    private int besatzungsgröße;
    

    /**
     * Konstruktor für Objekte der Klasse Schiff
     */
    public Schiff(String pHersteller, String pAntrieb, int pGeschwindigkeit, int pGewicht, int pBesatzungsgröße)
    {
        // Instanzvariable initialisieren
        hersteller = pHersteller;
        antrieb = pAntrieb;
        geschwindigkeit = pGeschwindigkeit;
        gewicht = pGewicht;
        besatzungsgröße = pBesatzungsgröße;
    }
    
    public String getHersteller() {
        return hersteller;
    }
    
    public void setHersteller(String hersteller) {
        this.hersteller = hersteller;
    }
    
    public String getAntrieb() {
        return antrieb;
    }
    
    public void setAntrieb(String antrieb) {
        this.antrieb = antrieb;
    }
    
    public int getGeschwindigkeit() {
        return geschwindigkeit;
    }
    
    public void setGeschwindigkeit(int geschwindigkeit) {
        this.geschwindigkeit = geschwindigkeit;
    }
    
    public int getGewicht() {
        return gewicht;
    }
    
    public void setGewicht(int gewicht) {
        this.gewicht = gewicht;
    }
    
    
}
