
/**
 * Beschreiben Sie hier die Klasse Güterschiff.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Passagierschiff extends Schiff
{
    // Instanzvariablen - ersetzen Sie das folgende Beispiel mit Ihren Variablen
    int MaxPersonen;
    boolean Hochseetauglich;

    /**
     * Konstruktor für Objekte der Klasse Güterschiff
     */
    public Passagierschiff(String pHersteller, String pAntrieb, int pGeschwindigkeit, int pGewicht, int pBesatzungsgröße, int pMaxPersonen, boolean pHochseetauglich)
    {
        super(pHersteller, pAntrieb, pGeschwindigkeit, pGewicht, pBesatzungsgröße);
        MaxPersonen = pMaxPersonen;
        Hochseetauglich = pHochseetauglich;
    }

    public int getMaxPersonen() 
    {
        return MaxPersonen;
    }
    
    public void setMaxPersonen(int MaxPersonen) 
    {
         this.MaxPersonen = MaxPersonen;
    }
    
    public boolean getHochseetauglich() 
    {
        return Hochseetauglich;
    }
    
    public void setMaxBeladung(boolean Tiertransport) 
    {
         this.Hochseetauglich = Hochseetauglich;
    }
}
